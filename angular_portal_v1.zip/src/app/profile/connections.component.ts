import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-connections',
  templateUrl: './connections.component.html',
  styleUrls: ['./connections.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ConnectionsComponent {

}
